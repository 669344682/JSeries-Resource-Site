unloadMap = true
AllowInteriors = false