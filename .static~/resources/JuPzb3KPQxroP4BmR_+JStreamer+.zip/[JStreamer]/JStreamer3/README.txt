Total Free Slots (Interior support disabled) 5563
Total Free Slots (Interior support enabled) 3353

If you would like to keep SAs map, change unload map to false in Settings  -> settings_S.lua (May cause some errors, I provide no real SA support at the moment)


To enable interior support (experimental) 'You most likely want to keep this disabled'

WARNING : You will loose 2210 slots total max objects will drop to 3353.
WARNING 2 : Not all interiors will show up

Settings - > Settings_S and Settings_C -> AllowInteriors -> True

