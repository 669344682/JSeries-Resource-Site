push_button = "1"
push_button2 = "2"

localPlayer = getLocalPlayer()

function getClosest(tableA) 
Distance = 5
Element = nil
local x,y,z = getElementPosition(localPlayer)
for i,v in pairs(tableA) do
local xA,yA,zA = getElementPosition(v)
local distance = getDistanceBetweenPoints3D (x,y,z,xA,yA,zA)
if distance < Distance then
Distance = distance
Element = v
end
end
return Element
end

bindKey(push_button2,"down",function()
if not  isElement(getElementData(localPlayer,"ggun_taken")) then
local tableA = {}
for i,v in pairs(getElementsByType("object")) do
if getElementModel(v) == 1598 then
table.insert(tableA,v)
end
end
local closest = getClosest(tableA)
if closest then
triggerServerEvent("ggun_take",root,closest)
setElementCollidableWith (closest,localPlayer,false) 
end
else
triggerServerEvent("ggun_drop",root,getElementData(localPlayer,"ggun_taken"))
end
end)


function returnCenterLineOfSite()
local w, h = guiGetScreenSize ()
local tx, ty, tz = getWorldFromScreenPosition ( w/2, h/2, 50 )
--local px, py, pz = getCameraMatrix()
--local hit, x, y, z = processLineOfSight ( px, py, pz, tx, ty, tz )
return tx, ty, tz+10
end


function returnBonePosition()
return getPedBonePosition (getLocalPlayer(),26)
end

Power = 0.3

function setPower(_,powerLevel)
if tonumber(powerLevel) then
if tonumber(powerLevel) > 0 and tonumber(powerLevel) < 11 then
Power = tonumber(powerLevel)/10
outputChatBox("Power set to "..Power)
end
end
end

addCommandHandler ( "setpower", setPower )


bindKey(push_button,"down",function()
local ggun_obj = getElementData(localPlayer,"ggun_taken")
	if isElement(ggun_obj) then
		if not ggun_obj then return end
		local x1,y1,z1 = getElementPosition(localPlayer)
		local x2,y2,z2 = returnCenterLineOfSite()
		x2,y2,z2 = x2-x1,y2-y1,z2-z1
		local spd = 1/math.sqrt(x2*x2+y2*y2+z2*z2)
		x2,y2,z2 = x2*spd,y2*spd,z2*spd
		triggerServerEvent("ggun_push",ggun_obj,x2*Power,y2*Power,z2*Power)
	end
end)



addEventHandler("onClientPreRender",root,function()
if getElementData(localPlayer,"ggun_taken") then
local x,y,z = returnBonePosition()
setElementData(localPlayer,"AimingAt",{x,y,z})
end

	local all_players = getElementsByType("player")
	for plnum,player in ipairs(all_players) do
		local taken = getElementData(player,"ggun_taken")
		if isElement(taken) then
			--local x1,y1,z1 = getPedTargetStart(player)
			local aimingT = getElementData(player,"AimingAt")
			local x2,y2,z2 = unpack(aimingT)
			--x2,y2,z2 = x2-x1,y2-y1,z2-z1
			--local dist = 5/math.sqrt(x2*x2+y2*y2+z2*z2)
			--x2,y2,z2 = x2*dist,y2*dist,z2*dist
			--local fx,fy,fz = x1+x2,y1+y2,z1+z2
			--local cx,cy,cz = getElementPosition(taken)
			--x2,y2,z2 = fx-cx,fy-cy,fz-cz
			--local spd = math.min(0.05*math.sqrt(x2*x2+y2*y2+z2*z2),0.1)
			--x2,y2,z2 = x2*spd,y2*spd,z2*spd
			setElementPosition(taken,x2,y2,z2)
		end
	end
end)