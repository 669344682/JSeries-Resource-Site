
function CreateBasketBall(Player)
local pX,pY,pZ = getElementPosition(Player)
local ball = exports.JStreamer3:JcreateObject(1598,pX,pY,pZ)
local ball2 = exports.JStreamer3:JcreateObject(2114,pX,pY,pZ)
attachElements(ball2,ball)
setElementAlpha(ball,0)
end
addCommandHandler("basketBall",CreateBasketBall)

addEvent("ggun_take",true)
addEventHandler("ggun_take",root,function(closest)
	if not isElement(getElementData(closest,"ggun_taker")) and not isElement(getElementData(client,"ggun_taken")) then
	setPedAnimation( client, "bsktball", "bball_pickup",300,false,true,true,false)
		setElementData(client,"ggun_taken",closest)
		setElementData(closest,"ggun_taker",client)
		setElementCollisionsEnabled(closest,false)
		
		bindKey(client,"3","down",storeBasketBall)
	end
end)

function storeBasketBall(player)
local ball = getElementData(player,"ggun_taken")

if isElement(ball) then
local attached = getAttachedElements(ball)
destroyElement(attached[1])
destroyElement(ball)
setElementData(player,"ggun_taken",true)
--exports.gunstorage:giveItem(player,"BasketBall#"..math.random(11232,1020303),1,"BasketBall")
end
end

addEvent("ggun_drop",true)
addEventHandler("ggun_drop",root,function(object)
		setElementCollisionsEnabled(object,true)	
	removeElementData(object,"ggun_taker")
	setElementData(client,"ggun_taken",true)
	unbindKey(client,"3","down",storeBasketBall)
end)

addEvent("ggun_push",true)
addEventHandler("ggun_push",root,function(vx,vy,vz)
	local taker = getElementData(source,"ggun_taker")
	if isElement(taker) then setElementData(taker,"ggun_taken",true) end
	removeElementData(source,"ggun_taker")
	setPedAnimation( client, "bsktball", "bball_jump_shot",300,false,true,true,false)
	setElementCollisionsEnabled(source,true)
	setElementVelocity(source,vx,vy,vz)
	unbindKey(client,"3","down",storeBasketBall)
end)